<!DOCTYPE html>
<html>
    <head>
        <title>Footer</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Limelight&family=Poiret+One&display=swap" rel="stylesheet">
        <style>
        body {
            background-color: #050505;
            margin: 0 auto;
        }
        h1 {
            color: white;
            font-family: 'Limelight', cursive;
            font-size: 2.5em;
        }
        a {
            font-family: 'Poiret One', cursive;
            font-size: 1.25em;
            color: white;
            text-decoration: none;
            width: 25%;
            text-align: center;
            font-weight: bold;
        }
        footer {
            margin: 0;
            padding: 2%;
            text-align: center;
            font-family: 'Poiret One', cursive;
            font-size: 1.25em;
            color: white;
            background-color: #c32a2a;
            border-top: 4px double #DAA520;
        }
       
        </style>
</head>
<?php require('mysqli_connect.php'); ?>
<footer>
    &copy; Adrian Hernandez <?php echo date('Y')?>
  </footer>
<html>