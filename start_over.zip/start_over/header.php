<!DOCTYPE html>
<html>
    <head>
        <title>Header</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Limelight&family=Poiret+One&display=swap" rel="stylesheet">
        <style>
        body {
            background-color: #050505;
            margin: 0 auto;
        }
        h1 {
            color: white;
            font-family: 'Limelight', cursive;
            font-size: 2.5em;
        }
        a {
            font-family: 'Poiret One', cursive;
            font-size: 1.25em;
            color: white;
            text-decoration: none;
            width: 25%;
            text-align: center;
            font-weight: bold;
        }
        header {
            margin: 0;
            padding: 2%;
            text-align: center;
            opacity: .9;
            background-color: #c32a2a;
            border-bottom: 4px double #DAA520;
        }
       
        </style>
</head>
<body>
        <header>
        <h1>Hollywood Match-Maker</h1>
        <nav>
        <a href="/start_over/list_users.php">User List |</a>
        <a href="/start_over/list_departments.php">Department List |</a>
        </nav>
        </header>
        <main>
        <?php require('mysqli_connect.php'); ?>
</main>
</body>
</html>