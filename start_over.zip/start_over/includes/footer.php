<!DOCTYPE html>
<html>
    <head>
        <title>Footer</title>
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Limelight&family=Poiret+One&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="/start_over/css/styles.css">
<body>
<footer>
    &copy; Adrian Hernandez <?php echo date('Y')?>
  </footer>
</body>
</html>
