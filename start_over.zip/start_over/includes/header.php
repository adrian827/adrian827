<!DOCTYPE html>
<html>
    <head>
        <title>Header</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Limelight&family=Poiret+One&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="/start_over/css/styles.css">
</head>
<body>
        <header>
        <ul>
        <li id="logo" style="float:left">Celebrity Match Maker</li>
        <li><a href="">Login</a></li>
        <li><a href="/start_over/users.php">Current Users</a></li>
        <li><a href="/start_over/index.php">Join Now!</a></li>
        </ul>
        </header>
        
</body>
</html>